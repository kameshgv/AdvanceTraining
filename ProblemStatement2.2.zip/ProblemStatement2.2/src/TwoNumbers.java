import java.util.Scanner;

class TwoNumbers {
  public static void main(String[] args) {
	  System.out.println("enter two numbers");
	  Scanner sc=new Scanner(System.in);
	  int num1=sc.nextInt();
	  int num2=sc.nextInt();
	  
	int i=0,n=14;
	int firstTerm = num1, secondTerm = num2;
    
      while (i <= n) {
      System.out.print(firstTerm + ", ");

      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;

      i++;
    }
  }
}
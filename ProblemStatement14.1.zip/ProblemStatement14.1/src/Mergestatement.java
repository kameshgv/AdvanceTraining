import java.util.*;
 
class Mergestatement{
     
    // Function to merge array in sorted order
    public static void sortedMerge(int a[], int b[],
                                  int res[], int n,
                                            int m)
    {
        // Sorting a[] and b[]
        Arrays.sort(a);
        Arrays.sort(b);
      
        // Merge two sorted arrays into res[]
        int i = 0, j = 0, k = 0;
        while (i < n && j < m) {
            if (a[i] <= b[j]) {
                res[k] = a[i];
                i += 1;
                k += 1;
            } else {
                res[k] = b[j];
                j += 1;
                k += 1;
            }
        }   
         
        while (i < n) {  // Merging remaining
                         // elements of a[] (if any)
            res[k] = a[i];
            i += 1;
            k += 1;
        }   
        while (j < m) {   // Merging remaining
                         // elements of b[] (if any)
            res[k] = b[j];
            j += 1;
            k += 1;
        }
    }
     
    /* Driver program to test above function */
    public static void main(String[] args)
    {
    	System.out.println("enter the first array");
    	Scanner scan=new Scanner(System.in);

		int []a;
		
		a = new int[3];
	    int []b;
		
		b = new int[3];
		   int n = a.length;
	        int m = b.length;
		
    	
    	for(int index = 0; index < a.length; index++) {
			a[index] = scan.nextInt();
		}
    	System.out.println("enter the second array");
    	
    	for(int index = 0; index < b.length; index++) {
			b[index] = scan.nextInt();
		}
    	 // Final merge list
        int res[] = new int[n + m];
        sortedMerge(a, b, res, n, m);
      
     
        System.out.print( " Sorted merged list :");
        for (int i = 0; i < n + m; i++)
            System.out.print(" " + res[i]);{  
        
        
    }}
}
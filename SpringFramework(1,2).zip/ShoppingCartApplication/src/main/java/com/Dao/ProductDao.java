package com.Dao;
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;  
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper; 
import com.bean.product; 
  
public class ProductDao {  
JdbcTemplate template;  
  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}  
public int save(product p){  
    String sql="insert into products(productname,productprice,productquantity) values('"+p.getProductname()+"',"+p.getProductprice()+",'"+p.getProductquantity()+"')";  
    return template.update(sql);  
}  
public int update(product p){  
    String sql="update products set productname='"+p.getProductname()+"', productprice="+p.getProductprice()+",productquantity='"+p.getProductquantity()+"' where productid="+p.getProductid()+"";  
    return template.update(sql);  
}  
public int delete(int productid){  
    String sql="delete from products where productid="+productid+"";  
    return template.update(sql);  
}  
public product getproductById(int productid){  
    String sql="select * from products where productid=?";  
    return template.queryForObject(sql, new Object[]{productid},new BeanPropertyRowMapper<product>(product.class));  
    //return template.queryForObject(sql, new Object[]{productid},new BeanPropertyRowMapper<Emp>(product.class));  
}  
public List<product> getproducts(){  
    return template.query("select * from products",new RowMapper<product>(){  
        public product mapRow(ResultSet rs, int row) throws SQLException {  
            product e=new product();  
            e.setProductid(rs.getInt(1));  
            e.setProductname(rs.getString(2));  
            e.setProductprice(rs.getInt(3));  
            e.setProductquantity(rs.getInt(4));  
            return e;  
        }  
    });  
}  
}  

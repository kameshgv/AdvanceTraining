package Rectangle;

public class Rectangle
{
 private float length, width;
 
 public Rectangle()
 {
  length = 1;
  width = 1;
 }
 public void setValues(float length,float width)
 {
  if (length > 0 && length < 20)
   this.length = length;
  if (width > 0 && width < 20)
   this.width = width;
 }
 public void doPerimeter()
 {
 System.out.println("perimeter of rectangle is "+((length+width)*2));
 }

 
 public void doArea()
 {
 System.out.println("area of rectangle is  "+length*width);
 }
 
 public float doLength()
 {
  return length;
 }
 
 public float doWidth()
 {
  return width;
 }

 }
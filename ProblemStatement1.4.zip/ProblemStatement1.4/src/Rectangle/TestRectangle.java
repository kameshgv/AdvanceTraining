package Rectangle;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		float width,length;
		System.out.println("enter the length an width");
		Scanner scan=new Scanner(System.in);
		 length=scan.nextFloat();
		 width=scan.nextFloat();
		 Rectangle ob=new Rectangle();
		 ob.setValues(length, width);
		 ob.doArea();
		 ob.doPerimeter();
	}

}
